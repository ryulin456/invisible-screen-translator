# -*- coding: utf-8 -*-
"""
Glass Translator —— 半透明「翻译玻璃板」

把这块半透明板子拖到任意英文内容上，它会实时识别板子背后框住的文字，
并把译文显示在板子上对应的位置（背后屏幕依稀可见）。
板子本身对截图 / 录屏 / 屏幕共享不可见（WDA_EXCLUDEFROMCAPTURE），
所以程序截取板子所在区域时，拿到的正好是板子"背后"的画面。

算力分工：
  OCR 文字识别 —— 本机 Windows 自带 OCR（免费、离线、几十毫秒）
  翻译        —— DeepSeek API（在 config.json 填 key），未填则用免费 Google 翻译

快捷键（全局，且支持单键秒切）：
  ` (波浪键/Esc下方) 或 F2 或 Alt+Q   瞬间显示 / 隐藏板子
  鼠标中键（点击板子任意处）            瞬间隐藏板子
  Alt+E        实时翻译 开/关
  Alt+R        立即重新识别
  Alt+T        鼠标穿透 开/关（开启后可直接点击板子背后的内容，但不能拖动板子）
  Alt+↑ / ↓    增加 / 降低板子不透明度
  Alt+Shift+Q  退出
"""
import asyncio
import ctypes
import json
import os
import queue
import re
import threading
import time
import tkinter as tk
import tkinter.font as tkfont
import urllib.parse
import urllib.request
from ctypes import wintypes

import numpy as np

from winrt.windows.globalization import Language
from winrt.windows.graphics.imaging import BitmapAlphaMode, BitmapPixelFormat, SoftwareBitmap
from winrt.windows.media.ocr import OcrEngine
from winrt.windows.storage.streams import DataWriter

HERE = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(HERE, "config.json")
DEFAULT_CONFIG = {
    "deepseek_api_key": "",
    "deepseek_base_url": "https://api.deepseek.com",
    "deepseek_model": "deepseek-chat",
    "target_lang": "auto",        # auto: 中文->英文，其他->中文；也可填 "zh" 或 "en"
    "ocr_engine": "auto",         # auto / rapid（准确，约1秒）/ windows（极快，需系统英文OCR包）
    "opacity": 0.82,              # 板子不透明度 0.3~1.0（越小越能看清背后）
    "interval": 0.8,              # 实时识别间隔（秒）
    "font": "Microsoft YaHei",
    "geometry": "720x360+200+200",
}


def load_config():
    cfg = dict(DEFAULT_CONFIG)
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, encoding="utf-8") as f:
                cfg.update(json.load(f))
        except Exception:
            pass
    else:
        save_config(cfg)
    return cfg


def save_config(cfg):
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)


CFG = load_config()

# ======================= Win32 =======================
user32 = ctypes.WinDLL("user32", use_last_error=True)
try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
except Exception:
    try:
        user32.SetProcessDPIAware()
    except Exception:
        pass

WDA_NONE, WDA_EXCLUDEFROMCAPTURE = 0x00, 0x11
GWL_EXSTYLE = -20
WS_EX_LAYERED, WS_EX_TRANSPARENT = 0x00080000, 0x00000020
WS_EX_TOOLWINDOW, WS_EX_APPWINDOW = 0x00000080, 0x00040000
MOD_ALT, MOD_SHIFT, MOD_NOREPEAT = 0x1, 0x4, 0x4000
VK_UP, VK_DOWN, VK_F2, VK_OEM_3 = 0x26, 0x28, 0x71, 0xC0
WM_HOTKEY = 0x0312
user32.SetWindowDisplayAffinity.argtypes = [wintypes.HWND, wintypes.DWORD]
user32.GetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int]
user32.GetWindowLongW.restype = ctypes.c_long
user32.SetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_long]
user32.SetWindowLongW.restype = ctypes.c_long
user32.RegisterHotKey.argtypes = [wintypes.HWND, ctypes.c_int, wintypes.UINT, wintypes.UINT]

# ======================= 截屏 =======================
try:
    import mss

    _MSS = getattr(mss, "MSS", None) or mss.mss
except Exception:
    mss = None


class Grabber:
    """在工作线程内使用（mss 对象不可跨线程）。返回 RGB ndarray。"""

    def __init__(self):
        self.sct = _MSS() if mss else None

    def grab(self, x, y, w, h):
        if self.sct:
            shot = self.sct.grab({"left": x, "top": y, "width": w, "height": h})
            return np.asarray(shot)[:, :, [2, 1, 0]]  # BGRA -> RGB
        from PIL import ImageGrab
        return np.asarray(ImageGrab.grab(bbox=(x, y, x + w, y + h), all_screens=True).convert("RGB"))


# ======================= OCR =======================
_CJK = re.compile(r"[\u3040-\u30ff\u3400-\u9fff\uac00-\ud7af]")


def _join_words(words):
    out = ""
    for w in words:
        if out and not _CJK.search(out[-1]) and not _CJK.search(w[0]) \
                and not re.match(r"[，。！？；：、,.!?;:)\]%]", w[0]):
            out += " "
        out += w
    return out


class Ocr:
    def __init__(self):
        langs = [l.language_tag for l in OcrEngine.available_recognizer_languages]
        eng = None
        # 有英文包优先用英文（识别英文更准），否则用中文包（中英都能识别）
        for tag in ("en-US", "en-GB", "zh-Hans-CN"):
            if tag in langs:
                eng = OcrEngine.try_create_from_language(Language(tag))
                break
        eng = eng or OcrEngine.try_create_from_user_profile_languages()
        if eng is None:
            raise RuntimeError("系统没有可用的 OCR 语言包")
        self.engine = eng
        self.loop = asyncio.new_event_loop()

    def recognize(self, rgb):
        """返回 [{'text', 'box':(x1,y1,x2,y2)}]，坐标为 rgb 图像坐标。"""
        h, w = rgb.shape[:2]
        # 小字放大 2 倍识别更准
        scale = 2 if w * h < 1_600_000 else 1
        if scale > 1:
            rgb = np.repeat(np.repeat(rgb, scale, axis=0), scale, axis=1)
            h, w = h * scale, w * scale
        bgra = np.empty((h, w, 4), np.uint8)
        bgra[..., 0], bgra[..., 1], bgra[..., 2], bgra[..., 3] = rgb[..., 2], rgb[..., 1], rgb[..., 0], 255
        dw = DataWriter()
        dw.write_bytes(bgra.tobytes())
        bmp = SoftwareBitmap.create_copy_from_buffer(
            dw.detach_buffer(), BitmapPixelFormat.BGRA8, w, h, BitmapAlphaMode.PREMULTIPLIED)
        res = self.loop.run_until_complete(self._run(bmp))
        out = []
        for ln in res.lines:
            ws = list(ln.words)
            if not ws:
                continue
            r = [wd.bounding_rect for wd in ws]
            box = (min(b.x for b in r) / scale, min(b.y for b in r) / scale,
                   max(b.x + b.width for b in r) / scale, max(b.y + b.height for b in r) / scale)
            out.append({"text": _join_words([wd.text for wd in ws]).strip(), "box": box})
        return out

    async def _run(self, bmp):
        return await self.engine.recognize_async(bmp)


class RapidOcr:
    """RapidOCR（PP-OCR 本地模型）：英文/中文识别准确，单次约 1 秒。"""

    def __init__(self):
        from rapidocr import RapidOCR
        self.engine = RapidOCR()

    def recognize(self, rgb):
        res = self.engine(np.ascontiguousarray(rgb), use_cls=False)
        out = []
        if res is None or res.boxes is None:
            return out
        for box, text, score in zip(res.boxes, res.txts, res.scores):
            if float(score) < 0.5 or not text.strip():
                continue
            b = np.asarray(box)
            out.append({"text": text.strip(),
                        "box": (float(b[:, 0].min()), float(b[:, 1].min()),
                                float(b[:, 0].max()), float(b[:, 1].max()))})
        return out


def create_ocr():
    """ocr_engine: auto / rapid / windows。
    auto：系统装了英文 OCR 包就用 Windows OCR（极快），否则用 RapidOCR（准确）。"""
    mode = CFG.get("ocr_engine", "auto")
    langs = [l.language_tag for l in OcrEngine.available_recognizer_languages]
    has_en = any(t.startswith("en") for t in langs)
    if mode == "windows" or (mode == "auto" and has_en):
        return Ocr(), "WinOCR"
    try:
        return RapidOcr(), "RapidOCR"
    except Exception:
        return Ocr(), "WinOCR"


_BULLET = re.compile(r"^[•●▪■◆◦·\-–—*]\s*")


def group_paragraphs(lines):
    """把 OCR 行合并成段落：上下间距小、左边对齐的行视为同一段。"""
    lines = sorted(lines, key=lambda l: (l["box"][1], l["box"][0]))
    paras = []
    for ln in lines:
        x1, y1, x2, y2 = ln["box"]
        lh = y2 - y1
        starts_bullet = bool(_BULLET.match(ln["text"]))
        best = None
        if not starts_bullet:
            for p in paras:
                px1, _, px2, py2 = p["box"]
                last = p["last"]
                gap = y1 - last[3]
                plh = last[3] - last[1]
                if -0.3 * lh < gap < 0.55 * max(lh, plh) and abs(lh - plh) < 0.45 * max(lh, plh) \
                        and abs(x1 - p["text_x"]) < 1.5 * lh and x1 < px2 and x2 > px1:
                    best = p
                    break
        if best:
            best["lines"].append(ln)
            best["last"] = ln["box"]
            bx = best["box"]
            best["box"] = (min(bx[0], x1), bx[1], max(bx[2], x2), y2)
        else:
            text_x = x1
            paras.append({"lines": [ln], "last": ln["box"], "box": ln["box"], "text_x": text_x})
    result = []
    for p in paras:
        text = ""
        for ln in p["lines"]:
            t = ln["text"]
            if text.endswith("-") and t[:1].islower():
                text = text[:-1] + t  # 合并断词
            else:
                text = (text + " " + t) if text else t
        text = _BULLET.sub("", text).strip()
        lh = float(np.median([l["box"][3] - l["box"][1] for l in p["lines"]]))
        result.append({"text": text, "box": p["box"], "lh": lh, "n": len(p["lines"])})
    return result


# ======================= 翻译 =======================
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}


def _http(url, data=None, headers=None, timeout=20):
    req = urllib.request.Request(url, data=data, headers={**UA, **(headers or {})})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8")


def target_of(text):
    t = CFG.get("target_lang", "auto")
    if t in ("zh", "en"):
        return t
    return "en" if _CJK.search(text) else "zh"


def deepseek_batch(texts, target):
    lang = "简体中文" if target == "zh" else "English"
    sys_prompt = (f"你是专业翻译。用户给出 JSON，其中 t 是屏幕 OCR 识别出的若干段文字（可能有少量识别错误，"
                  f"请按上下文纠正）。把每一段翻译成{lang}，译文简洁自然。"
                  f'只输出 JSON：{{"t": [译文1, 译文2, ...]}}，数组长度和顺序必须与输入一致。')
    body = json.dumps({
        "model": CFG["deepseek_model"],
        "temperature": 0.2,
        "response_format": {"type": "json_object"},
        "messages": [{"role": "system", "content": sys_prompt},
                     {"role": "user", "content": json.dumps({"t": texts}, ensure_ascii=False)}],
    }).encode()
    res = json.loads(_http(CFG["deepseek_base_url"].rstrip("/") + "/chat/completions", body,
                           {"Content-Type": "application/json",
                            "Authorization": "Bearer " + CFG["deepseek_api_key"]}, timeout=60))
    content = res["choices"][0]["message"]["content"]
    arr = json.loads(content[content.index("{"): content.rindex("}") + 1])["t"]
    if len(arr) != len(texts):
        raise ValueError("DeepSeek 返回条数不一致")
    return [str(a) for a in arr]


def google_one(text, target):
    tl = "zh-CN" if target == "zh" else "en"
    body = urllib.parse.urlencode({"q": text}).encode()
    url = f"https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl={tl}&dt=t"
    data = json.loads(_http(url, body, {"Content-Type": "application/x-www-form-urlencoded"}))
    return "".join(seg[0] for seg in data[0] if seg and seg[0])


def translate_batch(texts, target):
    if CFG.get("deepseek_api_key"):
        try:
            return deepseek_batch(texts, target), "DeepSeek"
        except Exception as e:
            err = f"DeepSeek失败:{e}"
    else:
        err = ""
    out = []
    for t in texts:
        try:
            out.append(google_one(t, target))
        except Exception:
            out.append(None)
    return out, ("Google" + (f"（{err}）" if err else ""))


# ======================= 热键 =======================
class Hotkeys(threading.Thread):
    def __init__(self, bindings, q):
        super().__init__(daemon=True)
        self.bindings, self.q = bindings, q

    def run(self):
        for i, (mod, vk, name) in enumerate(self.bindings, 1):
            if not user32.RegisterHotKey(None, i, mod | MOD_NOREPEAT if vk not in (VK_UP, VK_DOWN) else mod, vk):
                self.q.put(("toast", f"热键 {name} 注册失败（被占用）"))
        msg = wintypes.MSG()
        while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) != 0:
            if msg.message == WM_HOTKEY:
                self.q.put(("hotkey", self.bindings[msg.wParam - 1][2]))


# ======================= 主界面 =======================
class Glass:
    BG = "#111418"
    BAR = "#1d2228"
    FG = "#f2f2f2"
    DIM = "#7d8590"
    ACC = "#4ea1ff"

    def __init__(self):
        self.root = tk.Tk()
        r = self.root
        r.title("Glass")
        r.overrideredirect(True)
        r.attributes("-topmost", True)
        r.attributes("-alpha", CFG["opacity"])
        r.geometry(CFG["geometry"])
        r.configure(bg=self.BG)

        self.q = queue.Queue()
        self.cache = {}            # (text, target) -> 译文
        self.pending = set()
        self.prev_texts = set()
        self.live = True
        self.clickthrough = False
        self._prev_ct = False
        self.visible = True
        self.force = threading.Event()
        self.rect = None           # 画布在屏幕上的位置 (x, y, w, h)
        self.cap_rect = None       # 最近一次截图时画布的位置
        self.paras = []
        self.engine_name = "DeepSeek" if CFG.get("deepseek_api_key") else "Google"
        self.fonts = {}
        self.stealth_ok = False

        # 标题栏
        bar = tk.Frame(r, bg=self.BAR, height=26)
        bar.pack(fill="x")
        self.status = tk.Label(bar, bg=self.BAR, fg=self.DIM, font=(CFG["font"], 9), anchor="w")
        self.status.pack(side="left", fill="x", expand=True, padx=6)
        for txt, cmd, tip in (("✕", self.quit, ""), ("👁", self.toggle_visible, ""),
                              ("+", lambda: self.opacity(+0.06), ""),
                              ("−", lambda: self.opacity(-0.06), ""), ("⏯", self.toggle_live, "")):
            b = tk.Label(bar, text=txt, bg=self.BAR, fg=self.FG, padx=7, cursor="hand2", font=(CFG["font"], 10))
            b.pack(side="right")
            b.bind("<Button-1>", lambda e, c=cmd: c())
        for w in (bar, self.status):
            w.bind("<ButtonPress-1>", self._start_move)
            w.bind("<B1-Motion>", self._on_move)
            w.bind("<ButtonRelease-1>", lambda e: self._save_geom())

        self.canvas = tk.Canvas(r, bg=self.BG, highlightthickness=0, bd=0)
        self.canvas.pack(fill="both", expand=True)
        grip = tk.Label(r, text="◢", bg=self.BG, fg="#555", cursor="size_nw_se")
        grip.place(relx=1.0, rely=1.0, anchor="se")
        grip.bind("<ButtonPress-1>", self._start_resize)
        grip.bind("<B1-Motion>", self._on_resize)
        grip.bind("<ButtonRelease-1>", lambda e: self._save_geom())
        self.canvas.bind("<Configure>", lambda e: self._update_rect())
        self.canvas.bind("<Button-2>", lambda e: self.toggle_visible())
        bar.bind("<Button-2>", lambda e: self.toggle_visible())
        self.status.bind("<Button-2>", lambda e: self.toggle_visible())
        r.bind("<Configure>", lambda e: self._update_rect())

        r.update_idletasks()
        self._setup_win32()
        self._update_rect()

        Hotkeys([(MOD_ALT, ord("Q"), "Alt+Q"), (0, VK_OEM_3, "`(波浪键)"), (0, VK_F2, "F2"),
                 (MOD_ALT, ord("E"), "Alt+E"), (MOD_ALT, ord("R"), "Alt+R"),
                 (MOD_ALT, ord("T"), "Alt+T"), (MOD_ALT, VK_UP, "Alt+Up"), (MOD_ALT, VK_DOWN, "Alt+Down"),
                 (MOD_ALT | MOD_SHIFT, ord("Q"), "Alt+Shift+Q")], self.q).start()
        self.tq = queue.Queue()
        threading.Thread(target=self._capture_loop, daemon=True).start()
        threading.Thread(target=self._translate_loop, daemon=True).start()
        r.after(30, self._pump)
        self._set_status()
        if not CFG.get("deepseek_api_key"):
            self._hint("提示：在 config.json 填入 deepseek_api_key 可获得更好的翻译质量")

    # ---------- Win32 ----------
    def _hwnd(self):
        return int(self.root.wm_frame(), 16)

    def _setup_win32(self):
        hwnd = self._hwnd()
        st = user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
        user32.SetWindowLongW(hwnd, GWL_EXSTYLE, (st | WS_EX_TOOLWINDOW) & ~WS_EX_APPWINDOW)
        self.stealth_ok = bool(user32.SetWindowDisplayAffinity(hwnd, WDA_EXCLUDEFROMCAPTURE))

    def set_clickthrough(self, on):
        self.clickthrough = on
        hwnd = self._hwnd()
        st = user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
        st = (st | WS_EX_LAYERED | WS_EX_TRANSPARENT) if on else (st & ~WS_EX_TRANSPARENT)
        user32.SetWindowLongW(hwnd, GWL_EXSTYLE, st)
        self._set_status()

    # ---------- 窗口操作 ----------
    def _update_rect(self):
        c = self.canvas
        self.rect = (c.winfo_rootx(), c.winfo_rooty(), max(1, c.winfo_width()), max(1, c.winfo_height()))
        self._place_items()

    def _start_move(self, e):
        self._dx, self._dy = e.x_root - self.root.winfo_x(), e.y_root - self.root.winfo_y()

    def _on_move(self, e):
        self.root.geometry(f"+{e.x_root - self._dx}+{e.y_root - self._dy}")

    def _start_resize(self, e):
        self._rx, self._ry, self._rw, self._rh = e.x_root, e.y_root, self.root.winfo_width(), self.root.winfo_height()

    def _on_resize(self, e):
        self.root.geometry(f"{max(240, self._rw + e.x_root - self._rx)}x{max(120, self._rh + e.y_root - self._ry)}")

    def _save_geom(self):
        CFG["geometry"] = self.root.geometry()
        save_config(CFG)
        self.force.set()

    def opacity(self, d):
        CFG["opacity"] = round(min(1.0, max(0.3, CFG["opacity"] + d)), 2)
        self.root.attributes("-alpha", CFG["opacity"])
        save_config(CFG)
        self._set_status()

    def toggle_live(self):
        self.live = not self.live
        self._set_status()
        if self.live:
            self.force.set()

    def toggle_visible(self):
        self.visible = not self.visible
        if self.visible:
            self.root.attributes("-alpha", CFG["opacity"])
            self.set_clickthrough(self._prev_ct)
            self.force.set()
        else:
            self._prev_ct = self.clickthrough
            self.root.attributes("-alpha", 0.0)
            hwnd = self._hwnd()
            st = user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
            user32.SetWindowLongW(hwnd, GWL_EXSTYLE, st | WS_EX_LAYERED | WS_EX_TRANSPARENT)

    def quit(self):
        self._save_geom()
        self.root.destroy()
        os._exit(0)

    def _set_status(self, extra=""):
        s = [("隐身✓" if self.stealth_ok else "隐身✗"), ("实时✓" if self.live else "实时✗"),
             getattr(self, "ocr_name", "OCR加载中"), self.engine_name, f"{int(CFG['opacity'] * 100)}%"]
        if self.clickthrough:
            s.append("穿透中(Alt+T取消)")
        if extra:
            s.append(extra)
        self.status.config(text="  ".join(s), fg=self.ACC if self.stealth_ok else "#ff6b6b")

    def _hint(self, text, ms=5000):
        self.canvas.delete("hint")
        self.canvas.create_text(10, 10, text=text, anchor="nw", fill=self.DIM, font=self._font(13), tags="hint")
        self.root.after(ms, lambda: self.canvas.delete("hint"))

    # ---------- 消息泵 ----------
    def _pump(self):
        try:
            while True:
                kind, val = self.q.get_nowait()
                if kind == "hotkey":
                    {"Alt+Q": self.toggle_visible, "`(波浪键)": self.toggle_visible, "F2": self.toggle_visible,
                     "Alt+E": self.toggle_live, "Alt+R": self.force.set,
                     "Alt+T": lambda: self.set_clickthrough(not self.clickthrough),
                     "Alt+Up": lambda: self.opacity(+0.06), "Alt+Down": lambda: self.opacity(-0.06),
                     "Alt+Shift+Q": self.quit}[val]()
                elif kind == "toast":
                    self._hint(val)
                elif kind == "ocr":
                    self.cap_rect, self.paras = val
                    self._render()
                elif kind == "translated":
                    self.engine_name = val
                    self._set_status()
                    self._render()
        except queue.Empty:
            pass
        self.root.after(30, self._pump)

    # ---------- 截屏 + OCR 线程 ----------
    def _capture_loop(self):
        try:
            ocr, self.ocr_name = create_ocr()
            grab = Grabber()
            self.q.put(("translated", self.engine_name))
        except Exception as e:
            self.q.put(("toast", f"初始化失败: {e}"))
            return
        last_small, last_rect = None, None
        while True:
            forced = self.force.wait(CFG["interval"])
            self.force.clear()
            if not self.visible or (not self.live and not forced) or not self.rect or not self.stealth_ok:
                continue
            rect = self.rect
            try:
                img = grab.grab(*rect)
            except Exception as e:
                self.q.put(("toast", f"截屏失败: {e}"))
                time.sleep(2)
                continue
            small = img[::4, ::4].mean(axis=2)
            if not forced and rect == last_rect and last_small is not None and \
                    small.shape == last_small.shape and np.abs(small - last_small).mean() < 1.5:
                # 画面没变化：不重复 OCR，但上一次识别到的段落此时已"稳定"，可以送去翻译
                need = [k for k in self.prev_texts if k not in self.cache and k not in self.pending]
                if need:
                    self.pending.update(need)
                    self.tq.put(need)
                continue
            last_small, last_rect = small, rect
            try:
                lines = ocr.recognize(img)
            except Exception as e:
                self.q.put(("toast", f"OCR 失败: {e}"))
                continue
            paras = [p for p in group_paragraphs(lines)
                     if len(p["text"]) >= 2 and re.search(r"[A-Za-z\u3400-\u9fff]", p["text"])]
            for p in paras:
                p["target"] = target_of(p["text"])
            # 只翻译「连续两次识别都出现」的段落，避免拖动/滚动过程中浪费 API
            texts = {(p["text"], p["target"]) for p in paras}
            stable = texts & self.prev_texts if not forced else texts
            self.prev_texts = texts
            need = [k for k in stable if k not in self.cache and k not in self.pending]
            if need:
                self.pending.update(need)
                self.tq.put(need)
            self.q.put(("ocr", (rect, paras)))

    # ---------- 翻译线程 ----------
    def _translate_loop(self):
        while True:
            need = self.tq.get()
            while not self.tq.empty():  # 合并积压的请求
                need += self.tq.get_nowait()
            by_target = {}
            for t, tgt in dict.fromkeys(need):
                by_target.setdefault(tgt, []).append(t)
            name = self.engine_name
            for tgt, texts in by_target.items():
                for i in range(0, len(texts), 40):
                    chunk = texts[i:i + 40]
                    try:
                        res, name = translate_batch(chunk, tgt)
                    except Exception as e:
                        res, name = [None] * len(chunk), f"翻译失败:{e}"
                    for s, d in zip(chunk, res):
                        if d:
                            self.cache[(s, tgt)] = d
                        self.pending.discard((s, tgt))
            self.q.put(("translated", name))

    # ---------- 绘制 ----------
    def _font(self, px):
        px = max(10, int(px))
        if px not in self.fonts:
            self.fonts[px] = tkfont.Font(family=CFG["font"], size=-px)
        return self.fonts[px]

    def _render(self):
        c = self.canvas
        c.delete("item")
        for p in self.paras:
            x1, y1, x2, y2 = p["box"]
            bw = max(40, x2 - x1)
            bh = max(p["lh"], y2 - y1)
            tr = self.cache.get((p["text"], p["target"]))
            if tr:
                text, color = tr, self.FG
            else:
                text, color = p["text"], self.DIM  # 未翻译完成前显示灰色原文
            px = p["lh"] * 0.95
            item = c.create_text(x1, y1, text=text, anchor="nw", width=bw, fill=color,
                                 font=self._font(px), tags=("item", "rel"))
            # 自适应字号：译文高度不超过原文区域太多
            while px > 10:
                bb = c.bbox(item)
                if bb and bb[3] - bb[1] <= bh * 1.15 + 4:
                    break
                px -= 1
                c.itemconfig(item, font=self._font(px))
        self._place_items(reset=True)

    def _place_items(self, reset=False):
        """窗口移动时，让已绘制的译文跟随背后内容（保持与原文对齐），直到下一次识别。"""
        if not self.cap_rect or not self.rect:
            return
        dx = self.cap_rect[0] - self.rect[0]
        dy = self.cap_rect[1] - self.rect[1]
        prev = getattr(self, "_offset", (0, 0)) if not reset else (0, 0)
        mx, my = dx - prev[0], dy - prev[1]
        if mx or my:
            self.canvas.move("rel", mx, my)
        self._offset = (dx, dy)

    def run(self):
        self.root.mainloop()


if __name__ == "__main__":
    Glass().run()
