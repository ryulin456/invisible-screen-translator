# -*- coding: utf-8 -*-
"""
Stealth Screen Translator —— 透明全屏/半屏「原位翻译」覆盖层，且对截图/录屏/屏幕共享不可见。

效果：按快捷键 -> 截取屏幕 -> Windows 自带 OCR 识别文字 -> 翻译 -> 在原文字相同位置
      覆盖显示译文（用原背景色打底，像是界面直接变成了另一种语言）。
      覆盖层可鼠标穿透，不影响操作；对截图/OBS/会议共享不可见（WDA_EXCLUDEFROMCAPTURE）。

快捷键（全局）：
  Alt+Q        显示 / 隐藏翻译层（显示时自动识别并翻译）
  Alt+R        重新识别当前画面
  Alt+W        切换区域：全屏 / 左半 / 右半 / 上半 / 下半
  Alt+D        切换方向：自动(中->英, 其他->中) / 全部->中文 / 全部->英文
  Alt+E        实时模式开关（显示时每隔几秒自动刷新）
  Alt+Shift+Q  退出程序

依赖：pip install winrt-runtime winrt-Windows.Media.Ocr winrt-Windows.Graphics.Imaging
             winrt-Windows.Storage.Streams winrt-Windows.Globalization winrt-Windows.Foundation
             winrt-Windows.Foundation.Collections pillow numpy
"""
import asyncio
import ctypes
import json
import queue
import re
import threading
import time
import tkinter as tk
import tkinter.font as tkfont
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from ctypes import wintypes

import numpy as np
from PIL import ImageGrab

from winrt.windows.globalization import Language
from winrt.windows.graphics.imaging import BitmapAlphaMode, BitmapPixelFormat, SoftwareBitmap
from winrt.windows.media.ocr import OcrEngine
from winrt.windows.storage.streams import DataWriter

# ======================= 配置 =======================
CONFIG = {
    "live_interval": 2.0,        # 实时模式刷新间隔（秒）
    "font": "Microsoft YaHei",
    "min_font_px": 10,
    "stealth": True,             # 对截图/录屏不可见
    # 可选：OpenAI 兼容接口（填了 api_key 就优先使用，如 DeepSeek / 通义 / OpenAI）
    "openai_base_url": "https://api.deepseek.com/v1",
    "openai_api_key": "",
    "openai_model": "deepseek-chat",
}

# ======================= Win32 =======================
user32 = ctypes.WinDLL("user32", use_last_error=True)
try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)  # Per-monitor DPI，保证截图坐标与窗口坐标一致
except Exception:
    try:
        user32.SetProcessDPIAware()
    except Exception:
        pass

WDA_NONE, WDA_EXCLUDEFROMCAPTURE = 0x00, 0x11
GWL_EXSTYLE = -20
WS_EX_LAYERED = 0x00080000
WS_EX_TRANSPARENT = 0x00000020
WS_EX_TOOLWINDOW = 0x00000080
WS_EX_NOACTIVATE = 0x08000000
WS_EX_APPWINDOW = 0x00040000
MOD_ALT, MOD_CONTROL, MOD_SHIFT, MOD_NOREPEAT = 0x1, 0x2, 0x4, 0x4000
WM_HOTKEY = 0x0312

user32.SetWindowDisplayAffinity.argtypes = [wintypes.HWND, wintypes.DWORD]
user32.GetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int]
user32.GetWindowLongW.restype = ctypes.c_long
user32.SetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_long]
user32.SetWindowLongW.restype = ctypes.c_long
user32.RegisterHotKey.argtypes = [wintypes.HWND, ctypes.c_int, wintypes.UINT, wintypes.UINT]

TRANSPARENT_KEY = "#ff00fe"  # 该颜色在覆盖层中会被视为全透明

# ======================= OCR =======================
_CJK = re.compile(r"[\u3040-\u30ff\u3400-\u9fff\uac00-\ud7af]")


def _create_engine():
    langs = [l.language_tag for l in OcrEngine.available_recognizer_languages]
    for tag in ("zh-Hans-CN", "zh-Hans", "zh-CN"):
        if tag in langs:
            return OcrEngine.try_create_from_language(Language(tag))
    eng = OcrEngine.try_create_from_user_profile_languages()
    if eng is None and langs:
        eng = OcrEngine.try_create_from_language(Language(langs[0]))
    if eng is None:
        raise RuntimeError("系统没有可用的 OCR 语言包，请在 设置->时间和语言->语言 中安装中文/英文语言包")
    return eng


def _join_words(words):
    """中文 OCR 会把每个汉字当作一个 word，这里智能拼接：只有西文单词之间加空格。"""
    out = ""
    for w in words:
        if out and not _CJK.search(out[-1]) and not _CJK.search(w[0]) \
                and not re.match(r"[，。！？；：、,.!?;:)\]]", w[0]):
            out += " "
        out += w
    return out


class Ocr:
    def __init__(self):
        self.engine = _create_engine()
        self.loop = asyncio.new_event_loop()

    def recognize(self, bgra: np.ndarray):
        h, w = bgra.shape[:2]
        maxd = OcrEngine.max_image_dimension
        if w > maxd or h > maxd:
            raise RuntimeError("图像过大")
        dw = DataWriter()
        dw.write_bytes(bgra.tobytes())
        bmp = SoftwareBitmap.create_copy_from_buffer(
            dw.detach_buffer(), BitmapPixelFormat.BGRA8, w, h, BitmapAlphaMode.PREMULTIPLIED)
        res = self.loop.run_until_complete(self._run(bmp))
        lines = []
        for ln in res.lines:
            ws = list(ln.words)
            if not ws:
                continue
            xs = [wd.bounding_rect.x for wd in ws]
            ys = [wd.bounding_rect.y for wd in ws]
            x2 = [wd.bounding_rect.x + wd.bounding_rect.width for wd in ws]
            y2 = [wd.bounding_rect.y + wd.bounding_rect.height for wd in ws]
            text = _join_words([wd.text for wd in ws]).strip()
            lines.append({"text": text, "box": (min(xs), min(ys), max(x2), max(y2))})
        return lines

    async def _run(self, bmp):
        return await self.engine.recognize_async(bmp)


# ======================= 翻译 =======================
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
_cache = {}


def _http(url, data=None, headers=None, timeout=10):
    req = urllib.request.Request(url, data=data, headers={**UA, **(headers or {})})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8")


def _google_batch(texts, target):
    joined = "\n".join(t.replace("\n", " ") for t in texts)
    body = urllib.parse.urlencode({"q": joined}).encode()
    url = f"https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl={target}&dt=t"
    data = json.loads(_http(url, body, {"Content-Type": "application/x-www-form-urlencoded"}))
    out = "".join(seg[0] for seg in data[0] if seg and seg[0]).split("\n")
    if len(out) != len(texts):
        raise ValueError("line mismatch")
    return [o.strip() for o in out]


def _google_one(text, target):
    url = (f"https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl={target}"
           f"&dt=t&q={urllib.parse.quote(text)}")
    data = json.loads(_http(url))
    return "".join(seg[0] for seg in data[0] if seg and seg[0])


def _openai_batch(texts, target):
    lang = "简体中文" if target.startswith("zh") else "English"
    prompt = (f"把下面 JSON 数组中的每一项翻译成{lang}，这些是屏幕 OCR 识别出的界面文字，"
              f"保持数组长度和顺序不变，只输出 JSON 数组：\n" + json.dumps(texts, ensure_ascii=False))
    body = json.dumps({"model": CONFIG["openai_model"], "temperature": 0,
                       "messages": [{"role": "user", "content": prompt}]}).encode()
    res = json.loads(_http(CONFIG["openai_base_url"].rstrip("/") + "/chat/completions", body,
                           {"Content-Type": "application/json",
                            "Authorization": "Bearer " + CONFIG["openai_api_key"]}, timeout=30))
    content = res["choices"][0]["message"]["content"]
    arr = json.loads(content[content.index("["): content.rindex("]") + 1])
    if len(arr) != len(texts):
        raise ValueError("line mismatch")
    return [str(a) for a in arr]


def translate_many(texts, target):
    """批量翻译，带缓存。返回与 texts 等长的列表。"""
    todo = [t for t in dict.fromkeys(texts) if (t, target) not in _cache]
    for i in range(0, len(todo), 60):
        chunk = todo[i:i + 60]
        res = None
        if CONFIG["openai_api_key"]:
            try:
                res = _openai_batch(chunk, target)
            except Exception:
                res = None
        if res is None:
            try:
                res = _google_batch(chunk, target)
            except Exception:
                with ThreadPoolExecutor(8) as ex:
                    def one(t):
                        try:
                            return _google_one(t, target)
                        except Exception:
                            return None
                    res = list(ex.map(one, chunk))
        for src, dst in zip(chunk, res):
            if dst:
                _cache[(src, target)] = dst
    return [_cache.get((t, target)) for t in texts]


# ======================= 全局热键 =======================
class Hotkeys(threading.Thread):
    def __init__(self, bindings, out_q):
        super().__init__(daemon=True)
        self.bindings, self.q = bindings, out_q

    def run(self):
        for i, (mod, vk, name) in enumerate(self.bindings, 1):
            if not user32.RegisterHotKey(None, i, mod | MOD_NOREPEAT, vk):
                self.q.put(("error", f"热键注册失败: {name}（可能被其它程序占用）"))
        msg = wintypes.MSG()
        while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) != 0:
            if msg.message == WM_HOTKEY:
                self.q.put(("hotkey", self.bindings[msg.wParam - 1][2]))


# ======================= 覆盖层 =======================
REGIONS = ["全屏", "左半屏", "右半屏", "上半屏", "下半屏"]
DIRECTIONS = ["自动", "→中文", "→英文"]


class Overlay:
    def __init__(self):
        self.root = tk.Tk()
        r = self.root
        r.overrideredirect(True)
        r.attributes("-topmost", True)
        r.configure(bg=TRANSPARENT_KEY)
        r.attributes("-transparentcolor", TRANSPARENT_KEY)
        self.canvas = tk.Canvas(r, bg=TRANSPARENT_KEY, highlightthickness=0, bd=0)
        self.canvas.pack(fill="both", expand=True)

        self.sw, self.sh = r.winfo_screenwidth(), r.winfo_screenheight()
        self.region_i = 0
        self.dir_i = 0
        self.visible = False
        self.live = False
        self.busy = False
        self.job_id = 0
        self.fonts = {}
        self.ocr = None
        self.q = queue.Queue()

        self._place()
        r.update_idletasks()
        self._setup_win32()

        Hotkeys([
            (MOD_ALT, ord("Q"), "toggle"),
            (MOD_ALT, ord("R"), "refresh"),
            (MOD_ALT, ord("W"), "region"),
            (MOD_ALT, ord("D"), "direction"),
            (MOD_ALT, ord("E"), "live"),
            (MOD_ALT | MOD_SHIFT, ord("Q"), "quit"),
        ], self.q).start()

        threading.Thread(target=self._init_ocr, daemon=True).start()
        r.after(30, self._pump)
        self._toast("隐形翻译已启动  Alt+Q 显示/隐藏  Alt+W 区域  Alt+D 方向  Alt+E 实时  Alt+Shift+Q 退出", 4000)

    # ---------- 窗口 ----------
    def _region_rect(self):
        w, h = self.sw, self.sh
        return [(0, 0, w, h), (0, 0, w // 2, h), (w // 2, 0, w - w // 2, h),
                (0, 0, w, h // 2), (0, h // 2, w, h - h // 2)][self.region_i]

    def _place(self):
        x, y, w, h = self._region_rect()
        self.root.geometry(f"{w}x{h}+{x}+{y}")

    def _setup_win32(self):
        self.hwnd = int(self.root.wm_frame(), 16)
        st = user32.GetWindowLongW(self.hwnd, GWL_EXSTYLE)
        st = (st | WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE) & ~WS_EX_APPWINDOW
        user32.SetWindowLongW(self.hwnd, GWL_EXSTYLE, st)
        self.stealth_ok = bool(user32.SetWindowDisplayAffinity(
            self.hwnd, WDA_EXCLUDEFROMCAPTURE if CONFIG["stealth"] else WDA_NONE))

    def _init_ocr(self):
        try:
            self.ocr = Ocr()
        except Exception as e:
            self.q.put(("error", f"OCR 初始化失败: {e}"))

    # ---------- 事件循环 ----------
    def _pump(self):
        try:
            while True:
                kind, val = self.q.get_nowait()
                if kind == "hotkey":
                    self._on_hotkey(val)
                elif kind == "error":
                    self._toast(val, 5000)
                elif kind == "result":
                    self._render(*val)
        except queue.Empty:
            pass
        self.root.after(30, self._pump)

    def _on_hotkey(self, name):
        if name == "quit":
            self.root.destroy()
        elif name == "toggle":
            self.visible = not self.visible
            if self.visible:
                self.refresh()
            else:
                self.job_id += 1
                self.canvas.delete("all")
        elif name == "refresh":
            self.visible = True
            self.refresh()
        elif name == "region":
            self.region_i = (self.region_i + 1) % len(REGIONS)
            self.canvas.delete("all")
            self._place()
            self._toast("区域：" + REGIONS[self.region_i])
            if self.visible:
                self.root.after(150, self.refresh)
        elif name == "direction":
            self.dir_i = (self.dir_i + 1) % len(DIRECTIONS)
            self._toast("翻译方向：" + DIRECTIONS[self.dir_i])
            if self.visible:
                self.refresh()
        elif name == "live":
            self.live = not self.live
            self._toast("实时模式：" + ("开" if self.live else "关"))
            if self.live and self.visible:
                self.refresh()

    # ---------- 识别 + 翻译 ----------
    def refresh(self):
        if self.ocr is None:
            self._toast("OCR 正在初始化，请稍后…")
            return
        if self.busy:
            return
        self.busy = True
        self.job_id += 1
        job = self.job_id
        rect = self._region_rect()
        if not self.stealth_ok:
            # 如果隐身不可用，截图前先清空，避免把自己的译文截进去
            self.canvas.delete("all")
            self.root.update()
        if not self.canvas.find_withtag("item"):
            self._toast("识别中…", 800)
        threading.Thread(target=self._work, args=(job, rect), daemon=True).start()

    def _target_for(self, text):
        if self.dir_i == 1:
            return "zh-CN"
        if self.dir_i == 2:
            return "en"
        return "en" if _CJK.search(text) else "zh-CN"

    def _work(self, job, rect):
        try:
            x, y, w, h = rect
            img = ImageGrab.grab(bbox=(x, y, x + w, y + h), all_screens=True)
            rgb = np.asarray(img.convert("RGB"))
            bgra = np.empty((rgb.shape[0], rgb.shape[1], 4), np.uint8)
            bgra[..., 0], bgra[..., 1], bgra[..., 2], bgra[..., 3] = rgb[..., 2], rgb[..., 1], rgb[..., 0], 255
            lines = self.ocr.recognize(bgra)

            items, groups = [], {}
            for ln in lines:
                t = ln["text"]
                if len(t) < 2 or not re.search(r"[A-Za-z\u3400-\u9fff]", t):
                    continue
                tgt = self._target_for(t)
                # 已经是目标语言的行跳过
                if tgt.startswith("zh") and _CJK.search(t) and not re.search(r"[A-Za-z]{3,}", t):
                    continue
                if tgt == "en" and not _CJK.search(t):
                    continue
                ln["target"] = tgt
                items.append(ln)
                groups.setdefault(tgt, []).append(t)

            trans = {}
            for tgt, texts in groups.items():
                for s, d in zip(texts, translate_many(texts, tgt)):
                    trans[(s, tgt)] = d

            for ln in items:
                ln["trans"] = trans.get((ln["text"], ln["target"]))
                ln["bg"], ln["fg"] = self._colors(rgb, ln["box"])
            self.q.put(("result", (job, items)))
        except Exception as e:
            self.q.put(("error", f"出错: {e}"))
            self.q.put(("result", (job, None)))

    @staticmethod
    def _colors(rgb, box):
        """取文字框四周像素的中位数作为背景色，并选取对比色作为文字色。"""
        h, w = rgb.shape[:2]
        x1, y1, x2, y2 = [int(v) for v in box]
        p = 3
        x1, y1, x2, y2 = max(0, x1 - p), max(0, y1 - p), min(w - 1, x2 + p), min(h - 1, y2 + p)
        edge = np.concatenate([rgb[y1, x1:x2], rgb[y2, x1:x2], rgb[y1:y2, x1], rgb[y1:y2, x2]])
        if edge.size == 0:
            bg = np.array([32, 32, 32])
        else:
            bg = np.median(edge, axis=0).astype(int)
        lum = 0.299 * bg[0] + 0.587 * bg[1] + 0.114 * bg[2]
        bg_hex = "#%02x%02x%02x" % tuple(bg)
        if bg_hex.lower() == TRANSPARENT_KEY:
            bg_hex = "#fe00fe"
        return bg_hex, ("#111111" if lum > 140 else "#f5f5f5")

    # ---------- 绘制 ----------
    def _font(self, px):
        px = max(CONFIG["min_font_px"], int(px))
        if px not in self.fonts:
            self.fonts[px] = tkfont.Font(family=CONFIG["font"], size=-px)
        return self.fonts[px]

    def _render(self, job, items):
        self.busy = False
        if job != self.job_id or not self.visible:
            return
        if items is not None:
            self.canvas.delete("item")
            for ln in items:
                tr = ln.get("trans")
                if not tr:
                    continue
                x1, y1, x2, y2 = ln["box"]
                bw, bh = x2 - x1, y2 - y1
                px = bh * 0.85
                f = self._font(px)
                # 字号自适应：尽量塞进原文宽度
                while f.measure(tr) > bw * 1.05 and px > CONFIG["min_font_px"]:
                    px -= 1
                    f = self._font(px)
                tw = max(bw, f.measure(tr))
                pad = 2
                self.canvas.create_rectangle(x1 - pad, y1 - pad, x1 + tw + pad, y2 + pad,
                                             fill=ln["bg"], outline="", tags="item")
                self.canvas.create_text(x1, (y1 + y2) / 2, text=tr, anchor="w", font=f,
                                        fill=ln["fg"], tags="item")
        if self.live:
            self.root.after(int(CONFIG["live_interval"] * 1000), self._live_tick, job)

    def _live_tick(self, job):
        if self.live and self.visible and job == self.job_id:
            self.refresh()

    def _toast(self, text, ms=1500):
        self.canvas.delete("toast")
        x, y, w, h = self._region_rect()
        f = self._font(15)
        tw = f.measure(text)
        cx = w // 2
        self.canvas.create_rectangle(cx - tw // 2 - 12, 20, cx + tw // 2 + 12, 52,
                                     fill="#202020", outline="#4ea1ff", tags="toast")
        self.canvas.create_text(cx, 36, text=text, fill="#ffffff", font=f, tags="toast")
        tid = time.time()
        self._toast_id = tid
        self.root.after(ms, lambda: self._toast_id == tid and self.canvas.delete("toast"))

    def run(self):
        self.root.mainloop()


if __name__ == "__main__":
    Overlay().run()
