@echo off
start "" pythonw "%~dp0stealth_translator.py"
