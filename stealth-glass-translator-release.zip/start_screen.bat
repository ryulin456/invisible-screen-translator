@echo off
start "" pythonw "%~dp0screen_translator.py"
