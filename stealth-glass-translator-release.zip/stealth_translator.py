# -*- coding: utf-8 -*-
"""
Stealth Translator - 悬浮翻译窗，对截图/录屏/屏幕共享不可见（Windows 10 2004+）。

原理：SetWindowDisplayAffinity(hwnd, WDA_EXCLUDEFROMCAPTURE)
      窗口在本机显示器正常可见，但截图、OBS、腾讯会议/Zoom/Teams 共享画面里看不到。

功能：
  - 置顶、无边框、可拖动、半透明悬浮窗
  - 监听剪贴板：复制(Ctrl+C)任意文本自动翻译
  - 手动输入翻译（Enter 翻译）
  - 不显示在任务栏 / Alt+Tab 中
  - 仅使用 Python 标准库，无需 pip 安装
"""
import ctypes
import json
import re
import threading
import tkinter as tk
import urllib.parse
import urllib.request
from ctypes import wintypes

# ---------------- Win32 ----------------
user32 = ctypes.WinDLL("user32", use_last_error=True)
WDA_NONE = 0x00
WDA_EXCLUDEFROMCAPTURE = 0x11
GWL_EXSTYLE = -20
WS_EX_TOOLWINDOW = 0x00000080
WS_EX_APPWINDOW = 0x00040000

user32.SetWindowDisplayAffinity.argtypes = [wintypes.HWND, wintypes.DWORD]
user32.SetWindowDisplayAffinity.restype = wintypes.BOOL
user32.GetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int]
user32.GetWindowLongW.restype = ctypes.c_long
user32.SetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_long]
user32.SetWindowLongW.restype = ctypes.c_long

try:  # 高 DPI 清晰显示
    ctypes.windll.shcore.SetProcessDpiAwareness(1)
except Exception:
    pass


def get_hwnd(win: tk.Misc) -> int:
    win.update_idletasks()
    return int(win.wm_frame(), 16)


def set_capture_hidden(win: tk.Misc, hidden: bool) -> bool:
    hwnd = get_hwnd(win)
    ok = user32.SetWindowDisplayAffinity(hwnd, WDA_EXCLUDEFROMCAPTURE if hidden else WDA_NONE)
    return bool(ok)


def hide_from_taskbar(win: tk.Misc):
    hwnd = get_hwnd(win)
    style = user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
    style = (style & ~WS_EX_APPWINDOW) | WS_EX_TOOLWINDOW
    user32.SetWindowLongW(hwnd, GWL_EXSTYLE, style)


# ---------------- 翻译后端 ----------------
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}


def _get(url, timeout=8):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8")


def tr_google(text, target):
    url = ("https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl="
           f"{target}&dt=t&q={urllib.parse.quote(text)}")
    data = json.loads(_get(url))
    return "".join(seg[0] for seg in data[0] if seg and seg[0])


def tr_mymemory(text, target):
    src = "zh-CN" if re.search(r"[\u4e00-\u9fff]", text) else "en"
    if src.split("-")[0] == target.split("-")[0]:
        src = "en"
    url = ("https://api.mymemory.translated.net/get?q="
           f"{urllib.parse.quote(text[:500])}&langpair={src}|{target}")
    return json.loads(_get(url))["responseData"]["translatedText"]


BACKENDS = [("Google", tr_google), ("MyMemory", tr_mymemory)]


def translate(text):
    # 含中文 -> 译成英文；否则 -> 译成中文
    target = "en" if re.search(r"[\u4e00-\u9fff]", text) else "zh-CN"
    errors = []
    for name, fn in BACKENDS:
        try:
            res = fn(text, target)
            if res:
                return res, name
        except Exception as e:
            errors.append(f"{name}: {e}")
    return "翻译失败\n" + "\n".join(errors), "-"


# ---------------- UI ----------------
class App:
    BG = "#1e1e1e"
    FG = "#e6e6e6"
    ACC = "#4ea1ff"

    def __init__(self):
        self.root = tk.Tk()
        r = self.root
        r.title("ST")
        r.overrideredirect(True)
        r.attributes("-topmost", True)
        r.attributes("-alpha", 0.92)
        r.geometry("420x260+80+80")
        r.configure(bg=self.BG)

        self.stealth = True
        self.watch_clip = True
        self.last_clip = self._clip()

        # 标题栏
        bar = tk.Frame(r, bg="#2b2b2b")
        bar.pack(fill="x")
        self.status = tk.Label(bar, text="", bg="#2b2b2b", fg="#9a9a9a", font=("Microsoft YaHei", 9))
        self.status.pack(side="left", padx=6)
        for txt, cmd in (("✕", r.destroy), ("—", self.toggle_min),
                         ("📋", self.toggle_clip), ("👁", self.toggle_stealth)):
            b = tk.Label(bar, text=txt, bg="#2b2b2b", fg=self.FG, padx=6, cursor="hand2")
            b.pack(side="right")
            b.bind("<Button-1>", lambda e, c=cmd: c())
        for w in (bar, self.status):
            w.bind("<ButtonPress-1>", self._start_move)
            w.bind("<B1-Motion>", self._on_move)

        self.body = tk.Frame(r, bg=self.BG)
        self.body.pack(fill="both", expand=True)

        self.entry = tk.Entry(self.body, bg="#2d2d2d", fg=self.FG, insertbackground=self.FG,
                              relief="flat", font=("Microsoft YaHei", 10))
        self.entry.pack(fill="x", padx=6, pady=(6, 3), ipady=3)
        self.entry.bind("<Return>", lambda e: self.do_translate(self.entry.get()))

        self.out = tk.Text(self.body, bg=self.BG, fg=self.FG, relief="flat", wrap="word",
                           font=("Microsoft YaHei", 11), padx=6, pady=4)
        self.out.pack(fill="both", expand=True)

        grip = tk.Label(self.body, text="◢", bg=self.BG, fg="#555", cursor="size_nw_se")
        grip.place(relx=1.0, rely=1.0, anchor="se")
        grip.bind("<ButtonPress-1>", self._start_resize)
        grip.bind("<B1-Motion>", self._on_resize)

        r.bind("<Escape>", lambda e: r.destroy())
        r.after(50, self._apply_win32)
        r.after(500, self._poll_clip)
        self._show("复制任意文字即可自动翻译，或在上方输入后回车。\n"
                   "👁 切换防截屏  📋 切换剪贴板监听  — 折叠  ✕/Esc 退出")

    # --- win32 ---
    def _apply_win32(self):
        hide_from_taskbar(self.root)
        # 修改扩展样式后需要重新映射窗口
        self.root.withdraw()
        self.root.after(10, self._reshow)

    def _reshow(self):
        self.root.deiconify()
        self.root.attributes("-topmost", True)
        ok = set_capture_hidden(self.root, self.stealth)
        if not ok:
            self.stealth = False
        self._update_status()

    def toggle_stealth(self):
        self.stealth = not self.stealth
        if not set_capture_hidden(self.root, self.stealth):
            self.stealth = False
        self._update_status()

    def toggle_clip(self):
        self.watch_clip = not self.watch_clip
        self.last_clip = self._clip()
        self._update_status()

    def toggle_min(self):
        if self.body.winfo_ismapped():
            self._geom = self.root.geometry()
            self.body.pack_forget()
            self.root.geometry(f"{self.root.winfo_width()}x28")
        else:
            self.body.pack(fill="both", expand=True)
            self.root.geometry(self._geom)

    def _update_status(self, extra=""):
        s = ("隐身✓" if self.stealth else "隐身✗") + "  " + ("监听✓" if self.watch_clip else "监听✗")
        self.status.config(text=s + ("  " + extra if extra else ""),
                           fg=self.ACC if self.stealth else "#ff6b6b")

    # --- 拖动/缩放 ---
    def _start_move(self, e):
        self._dx, self._dy = e.x_root - self.root.winfo_x(), e.y_root - self.root.winfo_y()

    def _on_move(self, e):
        self.root.geometry(f"+{e.x_root - self._dx}+{e.y_root - self._dy}")

    def _start_resize(self, e):
        self._rx, self._ry = e.x_root, e.y_root
        self._rw, self._rh = self.root.winfo_width(), self.root.winfo_height()

    def _on_resize(self, e):
        w = max(200, self._rw + e.x_root - self._rx)
        h = max(100, self._rh + e.y_root - self._ry)
        self.root.geometry(f"{w}x{h}")

    # --- 剪贴板 ---
    def _clip(self):
        try:
            return self.root.clipboard_get()
        except Exception:
            return ""

    def _poll_clip(self):
        if self.watch_clip:
            c = self._clip()
            if c and c != self.last_clip:
                self.last_clip = c
                if c.strip() and len(c) < 5000:
                    self.do_translate(c)
        self.root.after(400, self._poll_clip)

    # --- 翻译 ---
    def do_translate(self, text):
        text = text.strip()
        if not text:
            return
        self._show("翻译中…")

        def work():
            res, name = translate(text)
            self.root.after(0, lambda: (self._show(res), self._update_status(name)))

        threading.Thread(target=work, daemon=True).start()

    def _show(self, s):
        self.out.config(state="normal")
        self.out.delete("1.0", "end")
        self.out.insert("1.0", s)

    def run(self):
        self.root.mainloop()


if __name__ == "__main__":
    App().run()
